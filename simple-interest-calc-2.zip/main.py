from tkinter import *
root=Tk()
root.geometry("400x350")
root.title("Simple Interest Calculator")
root.config(bg="pink")

def si():
  a=int(eprin.get())
  b=int(erate.get())
  c=int(etime.get())
  amount=(a*b*c)/100
  Label(text=f"{amount}",font=("arial",16,"bold"),bg="cadet blue").place(x=300,y=200)


prin=Label(root,text="Principal",font=("arial",16,"bold"),width=8)
prin.place(x=50,y=20)
Principal=StringVar()
eprin=Entry(root,textvariable=Principal,font=("arial",16,"bold"),width=8)
eprin.place(x=210,y=20)

rate=Label(root,text="Rate",font=("arial",16,"bold"),width=8)
rate.place(x=50,y=90)
Rate=StringVar()
erate=Entry(root,textvariable=Rate,font=("arial",16,"bold"),width=8)
erate.place(x=210,y=90)

time=Label(root,text="Time",font=("arial",16,"bold"),width=8)
time.place(x=50,y=160)
Time=StringVar()
etime=Entry(root,textvariable=Time,font=("arial",16,"bold"),width=8)
etime.place(x=210,y=160)

b1=Button(root,font=("arial",20,"bold"),text="Calculate",bg="red",command=si)
b1.place(x=40,y=200)

b1=Button(root,font=("arial",20,"bold"),text="Exit",bg="red",command=lambda:exit())
b1.place(x=210,y=200)

root.mainloop()