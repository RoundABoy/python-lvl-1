from tkinter import *
root=Tk()
root.title("EVEN ODD PROGRAM!")
root.geometry("450x300")
root.config(bg="pink")

def find():
  n=int(e1.get())
  if n%2==0:
    result.configure(text="Even Number!")
  else:
    result.configure(text="Odd Number!")

def clear():
  e1.delete(0,"end")
  result.configure(text="Result: ")

l1=Label(root,text="Enter number: ",fg="white",bg="cadet blue")
l1.grid(row=0,column=0)

e1=Entry(root,width=12,bg="pink",fg="black")
e1.grid(row=0,column=1)

b1=Button(root,text="Find",command=find)
b1.grid(row=1,column=0)

b2=Button(root,text="Clear",command=clear)
b2.grid(row=1,column=1)

result=Message(root,text="Result: ",width=300)
result.grid(row=2,column=0,columnspan=2)

root.mainloop()
