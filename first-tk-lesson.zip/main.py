'''from tkinter import *

root=Tk()
root.geometry("200x69")

root.title("Cheese!!!")
frame=Frame(root)
frame.pack()
root.config(bg="sky blue")

a=Label(root,text="Cheese\nCHEESE IS SO TASTY\n\nTHE BEST FOOD\n\nOBJECTIVELY!",bg="light blue",fg="white")
a.pack(side=BOTTOM)

def clicked():
  
  res="You coded!"
  a.configure(text="you've been jebaited")
b1=Button(frame,text="CHEESE TYPES",fg="cadet blue",command=clicked)
b1.pack()

"""b=Label(root,text="Cheese\n2",bg="light green")
b.grid(row=0, column=1)"""

root.mainloop()

'''
from tkinter import *
master=Tk()
master.geometry("400x300")
w=Canvas(master,width=10,height=60)
w.pack()
Canvas_height=20
Canvas_width=200
y=int(Canvas_height/2)
w.create_line(0,y,Canvas_width,y)
mainloop()
