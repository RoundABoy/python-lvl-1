for i in range(1,100000000002,2):
  print(i)