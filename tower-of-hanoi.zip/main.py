def tof(n,pole1,pole2,pole3):
  if n==1:
    print("Move disk 1 from",pole1,"to",pole3)
    return
  tof(n-1,pole1,pole2,pole3)
  print("move disk from",n,"from pole 1",pole1,"to pole 2",pole2)
  tof(n-1,pole1,pole2,pole3)
n=3
tof(n,"a","b","c")
