#amount=principle*(power(1+rate/100),time)
#Compound interest= amount - principle
from tkinter import *
root=Tk()
root.geometry("350x400")
root.config(bg="light blue")
root.title("Compound Interest Calc")

def CI():
  a=int(eprin.get())
  b=int(erate.get())
  c=int(etim.get())
  CI=a*(1+b/100)**c-a

prin=Label(root,text="Principle",font=("arial 15 "),width=8)
prin.place(x=50,y=150)
Principle=StringVar()
eprin=Entry(root,textvariable=Principle,font=("arial",15),width=7)
eprin.place(x=150,y=148)

rate=Label(root,text="Rate",font=("arial 15 "),width=8)
rate.place(x=50,y=200)
Rate=StringVar()
erate=Entry(root,textvariable=Rate,font=("arial 15"),width=7)
erate.place(x=150,y=198)

tim=Label(root,text="Time",font=("arial 15 "),width=8)
tim.place(x=50,y=250)
Time=StringVar()
etim=Entry(root,textvariable=Time,font=("arial 15 "),width=7)
etim.place(x=150,y=248)

comp=Label(root,text="Compound Interest",font=("arial 15 "),width=19)
comp.place(x=10,y=60)
Compound=StringVar()
ecomp=Entry(root,textvariable=Compound,font=("arial 15"),width=7)
ecomp.place(x=230,y=58)

b1=Button(root,font=("arial 20 bold"),text="Enter",bg="cadet blue",command=CI)
b1.place(x=80,y=300)

b2=Button(root,font=("arial 20 bold"),text="Exit",bg="cadet blue",command=lambda:exit())
b2.place(x=170,y=300)


