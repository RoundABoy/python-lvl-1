print("Welcome to the hub, To procceed and have access to all our features please verify yourself.")
print()
username=(input("Enter A Username: "))
userpass=(input("Enter A Password: "))
if(username=="Ansh" or username=="ansh"):
  print()
  print("Welcome Ansh")
  print()
  if(userpass=="Cheese123!"):
    print("Valid Credentials")
    ch=int(input("Enter 1 if you want to change your password\n or 2 to leave it."))
    if(ch==1):
      cp=(input("Enter your new password: "))
      if(len(cp)>=8):
        print("Strong password!")
      else:
        print("Make sure you have a stronger password with atleast 8 characters!")
        np=(input("Enter The New Password: "))
    else:
      print("Great")
print()
print("Please enter some security questions")
q1=str(input("Enter the name of your first pet: "))
if(q1=="John" or "john"):
  print("Good, Next Question.")
else:
  print("Try again")
q2=str(input("Enter the name of the country that you live in: "))
if(q2=="Uk" or "uk"):
  print("Perfect")
else:
  print("Try again")
otp=int(input("Enter the OTP sent to your email inbox, check the junk or spam: "))
if(otp=="123"):
  print("You have successfully verified yourself and now have full access to all our features!")
else:
  print("Error please check your junk or spam and enter the correct OTP")
notp=int(input("Enter the new otp: "))
if(notp=="456"):
    print("You have successfully verified yourself and now have full access to all our features!")
else:
  print("Your account has been locked out for breach in security!")


  


