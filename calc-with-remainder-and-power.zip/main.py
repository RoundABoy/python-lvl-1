a=float(input("Enter the first number: "))
b=float(input("Enter the second number: "))
ch=int(input("Enter 1 for addition \nEnter 2 for subtraction \nEnter 3 for multiplication \nEnter 4 for division \nEnter 5 for remainder \nEnter 6 for the power: "))
if(ch==1):
  print("The addition of these numbers is...",a+b)
elif(ch==2):
  print("The difference is...",a-b)
elif(ch==3):
  print("The product of these numbers are...",a*b)
elif(ch==4):
  print("The coeficient of these numbers is...",a/b)
elif(ch==5):
  print("The remainder is...",a//b)
elif(ch==6):
  print("The power is...",a**b)
else:
  print("this calc is hacked and corporate is now after you")