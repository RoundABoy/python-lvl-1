"""LIST:
built-in datatype which store multiple items in a single variable 
[]
ordered,changeable(add,remove),allow duplicates 
indexing: L TO R---> 0 to infinite
R to L ----> -1 to infinite
...........................................
a=[3.5,1,3.5,True,"apple","apple"]
print(a)
print(len(a))
print(type(a))
print(a[3])
print(a[-4])
print(a[0:5])
print(a[0:])
print(a[:4])
print(a[-4:-1])
print(a[-6:-2])
print(a[-5:-1])
print(a[-5:])
print(a[:-3])
...........................

a=["apple","mango","grapes","orange","pear","kiwi"]
print(a)
a[1]="blackcurrent"
print(a)
a[1:3]=["watermelon","muskmelon"]
print(a)
a.insert(2,"banana")
print(a)
a.append("blueberry")
print(a)  
.......................................
a=["apple","mango","grapes"]
b=["orange","pear","kiwi"]
a.extend(b)
print(a)
a.remove("kiwi")
print(a)
a.pop(3)
print(a)
a.pop()
print(a)
del a[2]
print(a)
#del a 
#print(a)
a.clear()
print(a) 
.............................
a=["apple","mango","grapes"]
for i in a:
  print(i)
..................
a=["apple","mango","grapes"]
for i in range(len(a)):
  print(a[i]) 
  .......................
i=0
a=["apple","mango","grapes"]
while(i<len(a)):
  print(a[i])
  i+=1   """
