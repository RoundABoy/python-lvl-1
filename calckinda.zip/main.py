from tkinter import *
root=Tk()
root.geometry("1080x720")
root.config(bg="cadet blue")

e1=Entry(root,font=("comic sans",20,"bold"),width=8,fg="light green",bg="pink")
e1.place(x=100,y=100)

e2=Entry(root,font=("comic sans",20,"bold"),width=8,fg="light green",bg="pink")
e2.place(x=100,y=200)

def addition():
  a=int(e1.get())
  b=int(e2.get())
  c=a+b


  l1=Label(root,width=7,height=6)
  l1.place(x=200,y=350)
  l2=Label(root,text=f'{c}',font=("comic sans",20,"bold"))
  l2.place(x=200,y=350)

b1=Button(root,text="+",width=7,font=("comic sans",20,"bold"),command=addition,bg="black",fg="white")
b1.place(x=300,y=200)

def subtraction():
  a=int(e1.get())
  b=int(e2.get())
  c=a-b
  
  l1=Label(root,width=7,height=7)
  l1.place(x=200,y=300)
  l2=Label(root,text=f'{c}',font=("comic sans",20,"bold"))
  l2.place(x=200,y=300)

b2=Button(root,text="-",width=7,font=("comic sans",20,"bold"),command=subtraction,bg="black",fg="white")
b2.place(x=500,y=200)


def multiplication():
  a=int(e1.get())
  b=int(e2.get())
  c=a*b

  l1=Label(root,width=7,height=7)
  l1.place(x=200,y=300)
  l2=Label(root,text=f'{c}',font=("comic sans",20,"bold"))
  l2.place(x=200,y=300)

b2=Button(root,text="*",width=7,font=("comic sans",20,"bold"),command=multiplication,bg="black",fg="white")
b2.place(x=500,y=100)



def division():
  a=int(e1.get())
  b=int(e2.get())
  c=a/b

  l1=Label(root,width=7,height=7)
  l1.place(x=200,y=300)
  l2=Label(root,text=f'{c}',font=("comic sans",20,"bold"))
  l2.place(x=200,y=300)

b2=Button(root,text="/",width=7,font=("comic sans",20,"bold"),command=division,bg="black",fg="white")
b2.place(x=300,y=100)


def remainder():
  a=int(e1.get())
  b=int(e2.get())
  c=a//b

  l1=Label(root,width=7,height=7)
  l1.place(x=200,y=300)
  l2=Label(root,text=f'{c}',font=("comic sans",20,"bold"))
  l2.place(x=200,y=300)

b2=Button(root,text="//",width=7,font=("comic sans",20,"bold"),command=remainder,bg="black",fg="white")
b2.place(x=300,y=300)


def modulous():
  a=int(e1.get())
  b=int(e2.get())
  c=a%b

  l1=Label(root,width=7,height=7)
  l1.place(x=200,y=300)
  l2=Label(root,text=f'{c}',font=("comic sans",20,"bold"))
  l2.place(x=200,y=300)

b2=Button(root,text="%",width=7,font=("comic sans",20,"bold"),command=modulous,bg="black",fg="white")
b2.place(x=500,y=300)

def power():
  a=int(e1.get())
  b=int(e2.get())
  c=a**b

  l1=Label(root,width=7,height=7)
  l1.place(x=200,y=300)
  l2=Label(root,text=f'{c}',font=("comic sans",20,"bold"))
  l2.place(x=200,y=300)

b2=Button(root,text="**",width=7,font=("comic sans",20,"bold"),command=power,bg="black",fg="white")
b2.place(x=400,y=400)



root.mainloop()

