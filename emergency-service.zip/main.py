'''a=[1,3,5,7,8,3,5,1,1,4,5,0,11,87]
a.sort()
print(a[-1])
print(a[0])
print(max(a))
print(min(a))

a=(1,4,3,6,8,1,12,15,0,0,2,3,121,4)
print(max(a))
print(min(a))

b=sorted(a)
print(b)


animals={
"lion":{
"class":"cat"},
"tiger":{
"class":"cat"}}
print(animals)

print("welcome to the Bank!\n")
credit=int(input("Please Enter your Credit Card Details:"))
print()
credit2=int(input("Please Enter it again for verification:\n"))
if(credit2==credit):
  print("Welcome, You are now verified!")
else:
  print("Locked out of Account!")'''


Contact=int(input("Hello, Who would you like to contact?\n1 for the doctor:\n2 for the pharmacy:\n3 for the police:\n4 for the fire deparment:"))
if(Contact==1):
  print("Phone number is 1233212323")
elif(Contact==2):
  print("Phone number is 07793715621")
elif(Contact==3):
  print("Phone number is 11848205883")
elif(Contact==4):
  print("Phone number is 03846978478")
else:
  print("Error")
print()
print("Just to confirm you want to call",Contact)





