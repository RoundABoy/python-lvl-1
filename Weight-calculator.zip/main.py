from tkinter import *
root=Tk()
root.geometry("350x400")
root.title("Weight Conversion Calculator")
root.config(bg="dark orange")

def convertounze():
  pass

def convertpound():
  pass

def convertgram():
  pass

def clear():
  pass

def close():
  pass

kg=Label(root,text='enter weight in kg',font=("universal condensed",10))
kg.place(x=100,y=70)

e1=Entry(root,font=("verdena",10),width=7)
e1.place(x=100,y=90)

pound=Button(root,text="pound",width=7,font=("verdena,10"),command=convertpound)